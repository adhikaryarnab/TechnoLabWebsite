import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(): boolean {
    const isAuthenticated = this.authService?.isAuthenticated() || false;

    if (isAuthenticated) {
      return true;
    } else {
      console.log('AuthGuard: redirecting to /admin_login');
      this.router.navigate(['/admin_login']);
      return false;
    }
  }
}
