import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedIn = false;

  // ✅ Add this method to fix the error
  setAuthenticated(status: boolean): void {
    this.loggedIn = status;
  }

  isAuthenticated(): boolean {
    // You can also check token presence here
    // return !!localStorage.getItem('adminToken');
    const adminToken = true//localStorage.getItem('adminToken');
    return !!adminToken;
  }

  logout(): void {
    localStorage.removeItem('adminToken');
  }
}
