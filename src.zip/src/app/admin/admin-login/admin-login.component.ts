import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ContactService } from '../../services/contact.service';
import { AuthService } from '../../auth';

@Component({
  selector: 'app-admin-login',
  standalone: false,
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent {

  adminlogin = {
    username: '',
    password: '',
  }
  
    // errorMessage = ''; // ✅ ✅ Declare this property

  constructor(private authService: AuthService, 
    private contactService: ContactService, private router: Router) {} // ✅ Inject Router
  
  submit(): void {
       // console.log("Contact data before sending:", this.contactData); // Debugging log
       this.contactService.validateAdminLogin(this.adminlogin).subscribe(
        (response: any) => {
          if (response.status) {
            console.log('Login successful:', response);
            // Option 1: Use setTimeout to defer navigation until after alert box closes
              alert('Login successful! Welcome, Admin.');
                setTimeout(() => {
                this.router.navigate(['/admin']);
                  }, 0); // Navigate to '/admin panel'
          } else {
            alert('Invalid username or password.');
          }
        },
        (error: any) => {
          console.error('Error submitting login data:', error);
          alert('Login failed! Please try again.');
        }
      );
  }

}

