import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth';

@Component({
  selector: 'app-admin-panel',
  standalone: false,
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.css']
})
export class AdminPanelComponent {

  registrations: any;
  pendingList: any;
  lastUpdate: any;
  activeFVUsers: any;

  constructor(private authService: AuthService,
    private router: Router) {} // ✅ Inject Router properly



 logout(): void {
  this.authService.logout(); // ✅ Use the service method
  alert('Logged out successfully!');
  this.router.navigate(['/admin_login']);
}

}


const lastUpdate = '10:14 PM';


