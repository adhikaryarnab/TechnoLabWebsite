import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AdminPanelComponent } from './admin/admin-panel/admin-panel.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { ContactComponent } from './components/contact/contact.component';
import { AboutComponent } from './components/about/about.component';
import { CoursesComponent } from './components/courses/courses.component';
import { AcFridgeRepearingComponent } from './components/ac-fridge-repearing/ac-fridge-repearing.component';
import { WebDesignCourseComponent } from './components/web-design-course/web-design-course.component';
import { HardwareNetworkingCourseComponent } from './components/hardware-networking-course/hardware-networking-course.component';
import { MobileRepearingComponent } from './components/mobile-repearing/mobile-repearing.component';
import { TvComputerRepearingComponent } from './components/tv-computer-repearing/tv-computer-repearing.component';
import { ComputerTrainingComponent } from './components/computer-training/computer-training.component';
import { OnlineApplicationComponent } from './components/online-application/online-application.component';
import { PageNotfoundComponent } from './components/page-notfound/page-notfound.component';
import { StudentRegistrationComponent } from './components/student-registration/student-registration.component';
import { ViewContactComponent } from './components/view-contact/view-contact.component';

import { AuthGuard } from './auth-guard'; // ✅ Import your AuthGuard
import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

const routes: Routes = [
  {path:'' , component:HomeComponent},
  {path:'contact' , component:ContactComponent},
  {path:'about' , component:AboutComponent},
  {path:'courses' , component:CoursesComponent},

  {path:'admin_login' , component:AdminLoginComponent},
  {path:'ac-fridge-repearing', component: AcFridgeRepearingComponent},
  {path:'web-design-course', component: WebDesignCourseComponent},
  {path:'hardware-networking-course', component: HardwareNetworkingCourseComponent},
  {path:'mobile-repearing' , component:MobileRepearingComponent},
  {path:'tv-computer-repearing' , component:TvComputerRepearingComponent},
  {path:'computer_training' , component:ComputerTrainingComponent},
  {path:'Appy-online' , component:OnlineApplicationComponent},
  {path:'page_not_found' , component:PageNotfoundComponent},
  {path:'view_registration' , component:StudentRegistrationComponent, canActivate: [AuthGuard]},
  {path: 'view_contact' , component:ViewContactComponent, canActivate: [AuthGuard]}, 
  {path:'admin' , component:AdminPanelComponent,canActivate: [AuthGuard]},

  // ✅ **These Pages lock with Login page [AuthGuard].**
  {path:'admin_login' , component:AdminLoginComponent},
  { path: 'admin', component: AdminPanelComponent, canActivate: [AuthGuard] },
  { path: 'view_registration', component: StudentRegistrationComponent, canActivate: [AuthGuard] },
  { path: 'view-contact', component: ViewContactComponent, canActivate: [AuthGuard] },
{ path: '**', redirectTo: 'admin_login', pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
@Injectable({
  providedIn: 'root'
})
export class authGuard implements CanActivate {
 isLoggedIn(): boolean {
  return !!localStorage.getItem('token');
}

 constructor(private auth: authGuard, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    if (this.auth.isLoggedIn()) {
      return true; // ✅ allow access
    } 
    // ✅ Redirect to login page and return false to block navigation
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
  
}
