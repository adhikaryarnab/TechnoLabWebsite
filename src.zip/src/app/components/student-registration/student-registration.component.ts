import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { AfterViewInit } from '@angular/core';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-student-registration',
  standalone: false,
  templateUrl: './student-registration.component.html',
  styleUrls: ['./student-registration.component.css']
})
export class StudentRegistrationComponent implements AfterViewInit {

    RegistrationArray: any[] = [];
    filteredRegistrations: any[] = [];
item: any;

   constructor(private http: HttpClient )
  {
    this.getAllRegistration();
  }

// // ✅Draggable editing PopUp Page ***
  ngAfterViewInit(): void {
    this.makeModalDraggable('editModalDialog', 'editModalHeader');
  }

  makeModalDraggable(modalId: string, headerId: string) {
    const modal = document.getElementById(modalId);
    const header = document.getElementById(headerId);

    if (!modal || !header) return;

    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;

    header.onmousedown = dragMouseDown;

    function dragMouseDown(e: MouseEvent) {
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;
      document.onmouseup = closeDragElement;
      document.onmousemove = elementDrag;
    }

    function elementDrag(e: MouseEvent) {
  e.preventDefault();
  pos1 = pos3 - e.clientX;
  pos2 = pos4 - e.clientY;
  pos3 = e.clientX;
  pos4 = e.clientY;

  // const modalEl = document.getElementById(modalId);
  // if (modalEl) {
  //   modalEl.style.top = (modalEl.offsetTop - pos2) + "px";
  //   modalEl.style.left = (modalEl.offsetLeft - pos1) + "px";
  //   modalEl.style.position = "absolute";
  // }
}

    function closeDragElement() {
      document.onmouseup = null;
      document.onmousemove = null;
    }
  }
  

  //// ✅Excel Button for export data.
  exportToExcel(): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.RegistrationArray);
    const workbook: XLSX.WorkBook = { Sheets: { 'Student Data': worksheet }, SheetNames: ['Student Data'] };
    
    // ✅ Save the file
    XLSX.writeFile(workbook, 'student_registration.xlsx');
  }


  //// ✅Submit button
  submit() {
  throw new Error('Method not implemented.');
  }
  
    // // ✅RegistrationArray : any[] = [];
    isResultLoaded = false;
    isUpdateFormActive = false;
  
    
    firstName: string ="";
    middleName: string ="";
    lastName: string ="";
    parentFirstName: string ="";
    parentMiddleName: string ="";
    parentLastName: string ="";
    email: string ="";
    phone: string ="";
    dob: string ="";
    gender: string ="";
    country: string ="";
    presentAddress: string ="";
    permanentAddress: string ="";
    state: string ="";
    city: string ="";
    pin: string ="";
    qualification: string ="";
    year: string ="";
    subject: string ="";
    coursetype: string ="";
    message: string ="";
    CurrentRegistrationID = "";
  

  ngOnInit(): void {
  }
  
// getAllRegistration() {
//   this.http.get("http://localhost:3000/api/registration/")
//     .subscribe((resultData: any) => {
//       this.isResultLoaded = true;
//       console.log(resultData.data);

//       // ✅ Add selected property to each item
//       this.RegistrationArray = resultData.data.map((item: any) => ({
//         ...item,
//         selected: false
//       }));
//     });
// }

getAllRegistration() {
  this.http.get("http://localhost:3000/api/registration/")
    .subscribe((resultData: any) => {
      this.isResultLoaded = true;
      this.RegistrationArray = resultData.data
        .filter((item: any) => item.IsDeleted !== 1); // 👈 Filter out deleted
    });
}



  masterSelected: boolean = false;

selectAll() {
  this.RegistrationArray.forEach(item => item.selected = this.masterSelected);
}

// editSelected() {
//   const selectedItems = this.RegistrationArray.filter(item => item.selected);
//   if (selectedItems.length === 1) {
//     this.setUpdate(selectedItems[0]);
//   } else {
//     alert('Please select exactly one item to edit.');
//   }
// }

deleteSelected() {
  const selectedItems = this.RegistrationArray.filter(item => item.selected);
  if (selectedItems.length > 0) {
    selectedItems.forEach(item => this.setDelete(item));
  } else {
    alert('No items selected for deletion.');
  }
}
  
  register()
  {
    let bodyData = {
      "firstName" : this.firstName,
      "middleName" : this.middleName,
      "lastName" : this.lastName,
      "parentFirstName" : this.parentFirstName,
      "parentMiddleName" : this.parentMiddleName,
      "parentLastName" : this.parentLastName,
      "email" : this.email,
      "phone" : this.phone,
      "dob" : this.dob,
      "gender" : this.gender,
      "country" : this.country,
      "presentAddress" : this.presentAddress,
      "permanentAddress" : this.permanentAddress,
      "state" : this.state,
      "city" : this.city,
      "pin" : this.pin,
      "qualification" : this.qualification,
      "year" : this.year,
      "subject" : this.subject,
      "coursetype" : this.coursetype,
      "message" : this.message
  
    };
  
    this.http.post("http://localhost:3000/api/registration/add/", bodyData).subscribe((resultData: any)=>
    {
      console.log(resultData);
      alert("Register Successfuly")
      this.getAllRegistration();
    });
  }
  
   setUpdate(data: any) 
    {
     this.firstName = data.firstName;
     this.middleName = data.middleName;
     this.lastName = data.lastName;
     this.parentFirstName = data.parentFirstName;
     this.parentMiddleName = data.parentMiddleName;
     this.parentLastName = data.parentLastName;
     this.email = data.email;
     this.phone = data.phone;
     this.dob = data.dob;
     this.gender = data.gender;
     this.country = data.country;
     this.presentAddress = data.presentAddress;
     this.permanentAddress = data.permanentAddress;
     this.state = data.state;
     this.city = data.city;
     this.pin = data.pin;
     this.qualification = data.qualification;
     this.year = data.year;
     this.subject = data.subject;
     this.coursetype = data.coursetype;
     this.message = data.message;
         
     this.CurrentRegistrationID = data.id;
   
    }
    UpdateRecords()
    {
      let bodyData = 
      {
      "firstName" : this.firstName,
      "middleName" : this.middleName,
      "lastName" : this.lastName,
      "parentFirstName" : this.parentFirstName,
      "parentMiddleName" : this.parentMiddleName,
      "parentLastName" : this.parentLastName,
      "email" : this.email,
      "phone" : this.phone,
      "dob" : this.dob,
      "gender" : this.gender,
      "country" : this.country,
      "presentAddress" : this.presentAddress,
      "permanentAddress" : this.permanentAddress,
      "state" : this.state,
      "city" : this.city,
      "pin" : this.pin,
      "qualification" : this.qualification,
      "year" : this.year,
      "subject" : this.subject,
      "coursetype" : this.coursetype,
      "message" : this.message
      };
      
      this.http.put("http://localhost:3000/api/registration/update/" + this.CurrentRegistrationID, bodyData)
    .subscribe({
      next: (updateResult: any) => {
        // // ✅Only log if update succeeds
        this.http.post("http://localhost:3000/api/register_logs/add/", {
          ...bodyData,
          registrationId: this.CurrentRegistrationID, // include ID for log trace, if appropriate
          action: 'update', // // ✅optionally log the action type
          logTime: new Date() // // ✅optional, backend can also make this
        }).subscribe({
          next: (logResult: any) => {
            alert("Student Registration Updated & Change logged Successfully");
            this.getAllRegistration();
          },
          error: (err) => {
            alert("Update succeeded but logging failed! Contact admin.");
          }
        });
      },
      error: (err) => {
        alert("Student Registration Update Failed");
      }
    });
}
          
      save()
    {
      if(this.CurrentRegistrationID == '')
      {
          this.register();
      }
        else
        {
         this.UpdateRecords();
        }       
    }
    // setDelete(data: any)
    // {
    //   this.http.delete("http://localhost:3000/api/registration/delete"+ "/"+ data.id).subscribe((resultData: any)=>
    //   {
    //       console.log(resultData);
    //       alert("Registration Deleted Successfully")
    //       this.getAllRegistration();
    //   });
    // } 
setDelete(data: any) {
  this.http.put("http://localhost:3000/api/registration/delete/" + data.id, {})
    .subscribe((resultData: any) => {
      console.log(resultData);
      alert("Registration marked as deleted");
      this.getAllRegistration();
    });
}

async editSelected() {
  const selectedItems = this.RegistrationArray.filter((item: any) => item.selected);
  if (selectedItems.length === 1) {
    this.setUpdate(selectedItems[0]);

    const modalElement = document.getElementById('editModal');
    if (modalElement) {
      const bootstrap = await import('bootstrap');
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  } else {
    alert('Please select exactly one row to edit.');
  }
}

}

