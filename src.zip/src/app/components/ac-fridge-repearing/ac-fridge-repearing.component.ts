import { Component } from '@angular/core';

@Component({
  selector: 'app-ac-fridge-repearing',
  standalone: false,
  templateUrl: './ac-fridge-repearing.component.html',
  styleUrls: ['./ac-fridge-repearing.component.css']
})
export class AcFridgeRepearingComponent {

}
