import { Component } from '@angular/core';

@Component({
  selector: 'app-hardware-networking-course',
  standalone: false,
  templateUrl: './hardware-networking-course.component.html',
  styleUrls: ['./hardware-networking-course.component.css']
})
export class HardwareNetworkingCourseComponent {

}
