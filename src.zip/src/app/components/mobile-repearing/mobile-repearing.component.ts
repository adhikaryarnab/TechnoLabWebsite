import { Component } from '@angular/core';

@Component({
  selector: 'app-mobile-repearing',
  standalone: false,
  templateUrl: './mobile-repearing.component.html',
  styleUrls: ['./mobile-repearing.component.css']
})
export class MobileRepearingComponent {

}
