import { Component } from '@angular/core';

@Component({
  selector: 'app-computer-training',
  standalone: false,
  templateUrl: './computer-training.component.html',
  styleUrls: ['./computer-training.component.css']
})
export class ComputerTrainingComponent {

}
