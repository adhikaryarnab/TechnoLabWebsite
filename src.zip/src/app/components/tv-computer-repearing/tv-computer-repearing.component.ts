import { Component } from '@angular/core';

@Component({
  selector: 'app-tv-computer-repearing',
  standalone: false,
  templateUrl: './tv-computer-repearing.component.html',
  styleUrls: ['./tv-computer-repearing.component.css']
})
export class TvComputerRepearingComponent {

}
