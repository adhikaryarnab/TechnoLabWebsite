import { Component } from '@angular/core';

@Component({
  selector: 'app-chip-eng-course',
  templateUrl: './chip-eng-course.component.html',
  styleUrls: ['./chip-eng-course.component.css']
})
export class ChipEngCourseComponent {

}
