import { Component } from '@angular/core';

@Component({
  selector: 'app-page-notfound',
  standalone: false,
  templateUrl: './page-notfound.component.html',
  styleUrls: ['./page-notfound.component.css']
})
export class PageNotfoundComponent {

}
